Reame.file

i. Bo Chen, bchen80@gatech.edu, bchen80

ii. Basic walk, backward, turning and running

iii. there is only one scene file named CharacterAnimation

iv. www.prism.gatech.edu/~bchen80/Chen_Bo_m1.html